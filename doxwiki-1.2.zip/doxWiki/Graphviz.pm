#! c:\perl\bin\perl
# Copyright 2006-2009 by Craig Dawson
#
# Distributed with the understanding that the owner(s) cannot be
# responsible for any behavior of the program or any damages that it
# may cause. See wikionly/LegalNotice.
#

use strict;
package Graphviz;
use File::Copy;

#
# Example of doxWiki extension using the update control.
# This simple example only outputs it's page, a more advanced
# example would read and parse @_ and modify the page.
# See WikiEdit for other tips and details.
# Note: this example is missing all sorts of error handling.
#

sub doit
{
    my @allLines;
    
    #chomp(my $cwd = `pwd`);
    
    push @allLines, "/'/':= update: use Graphviz;";
    push @allLines, "/'/':= update: return Graphviz::doit(\@_);";
    push @allLines, "/'/':= donotedit:";
    push @allLines, "/'/' Start Area Here";
    push @allLines, "!! GraphViz";
    push @allLines, "This page requires the [http://www.research.att.com/sw/tools/graphviz/ GraphViz] package to be installed.  It also uses the ''pwd'' command.";
    push @allLines, "* Script [Edit\@40] (should be located in doxwiki directory)";
    push @allLines, "* WikiPageNOwiki [Edit\@40] (make sure to use a wiki word)";
    push @allLines, "----";
    my $script = $main::EditBoxArray[1];
    my $page = $main::EditBoxArray[2];
    my $cmd = "dot -Tjpg $script -o $page.jpg";
    print STDERR "Spawning: $cmd\n";
    system($cmd);
    #system("cp $page.jpg images");
    copy("$page.jpg", "images");
    open(FILE, ">>pages/$page");
    print FILE "!! $page\n";
    print FILE "local://images/$page.jpg\n";
    close FILE;
    push @allLines, "";
    push @allLines, "Executed: $cmd";
    push @allLines, "!!! $script used to generate pages/$page" . "NOwiki" . " with images/$page" . "NOwiki" . ".jpg displayed on $page";

    return (@allLines);
}

1;
