#! c:\perl\bin\perl
# Copyright 2004-2009 by Keith McClelland
#
# Distributed with the understanding that the owner(s) cannot be
# responsible for any behavior of the program or any damages that it
# may cause. See wikionly/LegalNotice.
#

#
# This file takes a doxWiki page as input and provides a list of
# "donotlink" control lines for every WikiWord in the file. The
# user can then pick and choose the ones that should really not
# be links and copy them into the page.
#

use strict;
my $link = "([A-Z][a-z0-9]+(?:[A-Z][a-z0-9]+)+)";

my %list;
my $donotlink = undef;
while (<STDIN>)
{
    #
    # First we collect any donotlinks
    #
    if (m!^/\047/\047:= \s+ donotlink\b (?: (?: :\s* | \s+) (\S*.*) )?!ix and
        length $1)
    {
        my $value = ($1 || '');
        $donotlink .= '|' if defined $donotlink;
        $value =~ s/^\s*|\s*$//g;
        $donotlink .= $value;
    }

    #
    # The only kinds of comment we like is a cssfile comment
    # or myrefs
    #
    s(/'/'.*)() unless m(^/'/':=\s+(?:cssfile|myrefs)\s)i;
    foreach (/\b$link\b/go)
    {
        $list{$_} = 1
            unless defined $donotlink and m/$donotlink/;
    }
}

foreach (sort keys %list)
{
    print "/'/':= donotlink $_\n";
}
