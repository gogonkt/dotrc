#! c:\perl\bin\perl
# Copyright 2006-2009 by Craig Dawson
#
# Distributed with the understanding that the owner(s) cannot be
# responsible for any behavior of the program or any damages that it
# may cause. See wikionly/LegalNotice.
#

use strict;
package Importpdf;
use File::Copy;

#
# Import PDF to doxWiki
#
sub doit
{
    my @allLines;
    
    push @allLines, "/'/':= update: use Importpdf;";
    push @allLines, "/'/':= update: return Importpdf::doit(\@_);";
    push @allLines, "/'/':= donotedit:";
    push @allLines, "/'/' Start Area Here";
    push @allLines, "!! Importpdf";
    push @allLines, "* PDF to Import [Edit\@40] (will be copied to pdf directory)";
    push @allLines, "* PDF Title [Edit\@40]";
    push @allLines, "* WikiPageNOwiki [Edit\@40] (make sure to use a wiki word)";
    push @allLines, "----";
    my $rawpdf = $main::EditBoxArray[1];
    my $pdftitle = $main::EditBoxArray[2];
    my $pdf = URLDecode($rawpdf);
    my @path = split /([\/\\])/, $pdf;
    my $root = pop @path;
    my $page = $main::EditBoxArray[3];
    copy($pdf, "pdf/$root");
    print STDERR "copy $pdf to pdf/$root complete.\n";
    open(FILE, ">>pages/$page");
    print FILE "\n!!! $pdftitle\n";
    print FILE "* [local://pdf/$root Imported PDF $root]\n";
    close FILE;
    push @allLines, "";
    push @allLines, "!!! Page $page was appended.";
    push @allLines, "!!! Copied $pdf to pdf/$root";

    return (@allLines);
}

sub URLDecode {
    my $theURL = $_[0];
    $theURL =~ tr/+/ /;
    $theURL =~ s/%([a-fA-F0-9]{2,2})/chr(hex($1))/eg;
    $theURL =~ s/<!--(.|\n)*-->//g;
    return $theURL;
}

1;
