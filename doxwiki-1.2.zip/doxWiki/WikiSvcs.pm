#! c:\perl\bin\perl
# Copyright 2004-2009 by Keith McClelland
#
# Distributed with the understanding that the owner(s) cannot be
# responsible for any behavior of the program or any damages that it
# may cause. See wikionly/LegalNotice.
#

use strict;
use POSIX qw(strftime);
package WikiSvcs;

my @startPages = qw (pages wikionly config);

#
# sub NextDir
#
# This subroutine provides the caller with a series
# of directories to search for wiki pages. Use it
# exactly as shown below; trust it to work; don't play
# with the control array.
#
# This routine is tricky because it doesn't read the
# control file (config/MorePages) unless necessary
# and then not more than once per cgi invocation.
#
# my @dirCtl; # Control variable; use it for multiple
#             # accesses to the list of directories
#
# for ($dirCtl[0] = 0; ; )
# {
#     my $dir = &WikiSvcs::NextDir(\@dirCtl);
#     last unless defined $dir;
#     ... use $dir ...
# }
#
sub NextDir
{
    my $dc = $_[0];
    splice @{$dc}, 1, 0, @startPages
        if @{$dc} == 1 and ${$dc}[0] == 0;
    return undef unless @{$dc} and ${$dc}[0] >= 0;

    if (${$dc}[0] == @startPages and
        $#{$dc} == @startPages and
        -e "config/MorePages" and
        open MP, "<", "config/MorePages")
    {
        while (<MP>)
        {
            s/[\r\n]//g;
            push @{$dc}, $1
                if m/^(?:[\d]+\. |
                   [!@%~]{2,} |
                   [#*]*)
                   \s* \[x\] \s* (.+)/x;
        }
        close MP;
    }

    return undef if ++${$dc}[0] >= @{$dc};
    return ${$dc}[${$dc}[0]];
}

#
# This routine returns the html template. With no argument, it
# is the wiki template. With a true argument, it is a template
# for export.
#
sub HtmlTemplate
{
    my $bare     = shift;
       $bare     = '' unless defined $bare;
    my $redirect = shift;
       $redirect = '' unless defined $redirect;
    my $newPage  = shift;

my $pt1 = << 'pt1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en-US">
<head>
  <meta http-equiv="content-type" content="application/xhtml+xml; charset=UTF-8" />
  <title
pt1xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

my $pt2a = << 'pt2axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
>Wiki: $title</title
pt2axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

my $pt2b = << 'pt2bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
>$title</title
pt2bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx



my $pt3 = << 'pt3xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
><style type="text/css">
$css</style>
</head
pt3xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx



my $pt4a = << 'pt4axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
><body
><h1>
  <img src="/images/logo.png" alt="wiki logo"/>
pt4axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


my $pt4b = << 'pt4bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
  <a href="search.cgi?search=$page*">$title</a>$inref
pt4bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


my $pt4c = << 'pt4cxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
  $title
pt4cxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


my $pt4d = << 'pt4dxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
</h1
>$form1<table cellspacing="0" cellpadding="5"><tr
><td align="center">$action1</td
><td align="left" valign="top">$htmlRef</td
></tr><tr><td colspan="2" align="right"
><small><a href="wiki.cgi?WikiRoot">WikiRoot</a
>&nbsp;<a href="wiki.cgi?BeenThere">BeenThere&nbsp;</a
>$myrefs</small></td></tr></table
>$body<table cellspacing="0" cellpadding="5"><tr
><td align="center">$action2</td
><td align="left">$summary<br/><small
> <a href="wiki.cgi?WikiRoot">WikiRoot</a
>&nbsp;<a href="wiki.cgi?BeenThere">BeenThere&nbsp;</a
>$myrefs</small></td
></tr></table
>$form2</body
pt4dxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

my $pt5 = << 'pt5xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
><body
>$body</body
pt5xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

my $pt7 = << 'pt7xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
></html>
pt7xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


my $pt8a = << 'pt8axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
>Jump to a Personal Wiki page</title></head>

<body><script>

var stuff       = document.URL;
var wherePut    = 2 + stuff.indexOf('//');
var endit       = 1 + stuff.lastIndexOf('/');
var quest       = 1 + stuff.indexOf('?');
var compname    = stuff.substring(wherePut, endit);
    wherePut   += 1 + compname.indexOf('/');
var realWiki    = stuff.substring(0, wherePut) +
                  stuff.substring(wherePut, endit) +
                  'wiki.cgi?' +
pt8axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


my $pt8b = << 'pt8bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
                  stuff.substring(quest);
pt8bxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


my $pt8c = << 'pt8cxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';

window.location.replace(realWiki);

</script></body></html>
pt8cxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

    if ($redirect eq "edit")
    {
        return $pt1 . $pt8a .
            (defined $newPage ? "'$newPage';" : $pt8b) . $pt8c;
    }
    elsif ($redirect eq "save")
    {
        return  $pt1 . $pt8a . $pt8b . $pt8c;
    }
    elsif ($bare)
    {
        return  $pt1 . $pt2b . $pt3 . $pt5 . $pt7;
    }
    elsif (defined $main::inputFromCaller)
    {
        return  $pt1 . $pt2a .  $pt3 . $pt4a . $pt4c . $pt4d . $pt7;
    }
    else
    {
        return  $pt1 . $pt2a .  $pt3 . $pt4a . $pt4b . $pt4d . $pt7;
    }
}

#
# This function allows doxWiki and the user to format the time in various ways.
#
# The first argument can take three forms:
#   undef - (corresponding to [Timestamp] inputs with no "@") -- use strftime's
#           "%c" format which means a locale-appropriate date and time
#   empty - (corresponding to an "@" with nothing after it -- use doxWiki's
#           special format "%a %H:%M:%S %x" which is locale-day, 24-hr time,
#           locale-date
#   otherwise - the string that is found is used as input to strftime and 
#               the user gets whatever he asked for
#
sub fmttime
{
    my @times = (@_ > 1) ?
                localtime($^T - ($_[1]) * 24 * 60 * 60) :
                localtime;
    my $fmt = "%c"; # no-input default which means locale-appropriate
    if (defined $_[0]) # that is, there is something in argument 0
    {
        #
        # Use whatever you get if you get it -- if empty use our special one
        #
        $fmt = (length $_[0]) ? $_[0] : "%a %H:%M:%S %x";
    }
    return &POSIX::strftime($fmt, @times);
}

1;
