#! c:\perl\bin\perl
# Copyright 2004-2009 by Keith McClelland
#
# Distributed with the understanding that the owner(s) cannot be
# responsible for any behavior of the program or any damages that it
# may cause. See wikionly/LegalNotice.
#

#
# This file finds all of the links in all of the files referenced in
# MorePages and outputs a list of files and their links. Special cases
# are handled as follows:
#   * /'/':= cssfile and /'/':= myrefs lines are recognized as
#     holding valid links
#   * /'/':= donotlink lines are honored
#   * Multiple instances of a link are reported only once
#
# The output consists of the file name followed by a space and the list
# of links separated by commas.
#

use strict;
use WikiSvcs;

$|++;
my $link = "([A-Z][a-z0-9]+(?:[A-Z][a-z0-9]+)+)";
our %files;
our @xfiles;
our @dirCtl;

my %list;
for ($dirCtl[0] = 0; ; )
{
    my $dir = &WikiSvcs::NextDir(\@dirCtl);
    last unless defined $dir;

    if (opendir DIR, $dir)
    {
        @xfiles = sort grep /^$link$/o, readdir(DIR);
        closedir(DIR);
        foreach my $file (@xfiles)
        {
            my $donotlink = undef;
            if(open LOOKY, "${dir}/${file}")
            {
                while (<LOOKY>)
                {
                    #
                    # First we collect any donotlinks
                    #
                    if (m!^/\047/\047:= \s+ donotlink
                        (?: (?: :\s* | \s+) (\S*.*) )?!ix)
                    {
                        my $value = ($1 || '');
                        $donotlink .= '|' if defined $donotlink;
                        $value =~ s/^\s*|\s*$//g;
                        $donotlink .= $value;
                    }

                    #
                    # The only kinds of comment we like is a cssfile comment
                    # or myrefs
                    #
                    s(/'/'.*)() unless m(^/'/':=\s+(?:cssfile|myrefs)\s)i;
                    foreach (/\b$link\b/go)
                    {
                        $list{$file} .= "$_,"
                            unless $list{$file} =~ m/$_,/ or
                            (defined $donotlink and m/$donotlink/);
                    }
                }
                close LOOKY;
            }
        }
    }
}

foreach (sort keys %list)
{
    chop $list{$_} if $list{$_} =~ m/,$/;
    print "$_ $list{$_}\n";
}
