#! c:\perl\bin\perl
# Copyright 2006-2009 by Keith McClelland
#
# Distributed with the understanding that the owner(s) cannot be
# responsible for any behavior of the program or any damages that it
# may cause. See wikionly/LegalNotice.
#

use strict;
package Setprefs;

#
# This update subroutine modifies "config/setprefs.conf" to record
# whatever has been set in the "SetPrefs" wiki page.
#
# This version is a simplified one that only does "editht".
# Abstract it so that each IP has associated symbol-value pairs
# in which the text keys (editht in this case) and the values are
# associated on the line with the IP.
#
sub doit
{
    my %prefs;
    foreach my $ink (@_)
    {
        if ($ink =~ m(\[x\].*/'/'\s*editht\s*(\d+)) and
            exists $main::EditBoxArray[$1])
        {
            my $valu = $main::EditBoxArray[$1];
            my $ipIs = 0;
            my %prefs;
            if ($valu =~ m/^\d+$/)
            {
                $ipIs = $ENV{REMOTE_ADDR} if defined $ENV{REMOTE_ADDR};
                if (-e "config/setprefs.conf" and 
                    open PREFS, "config/setprefs.conf")
                {
                    while (<PREFS>)
                    {
                        $prefs{$1} = $2 if m/^(\S+)\s+(\S.*)/;
                    }
                    close PREFS;
                }
                if (not $valu) # Zero means remove it.
                {
                    delete $prefs{$ipIs};
                }
                else
                {
                    $prefs{$ipIs} = $valu;
                }
                if (open PREFS, ">", "config/setprefs.conf")
                {
                    printf PREFS "%s %s\n", $_, $prefs{$_}
                         foreach (sort keys %prefs);
                    close PREFS;
                }
            }
        }
    }

    return @_;
}

1;
