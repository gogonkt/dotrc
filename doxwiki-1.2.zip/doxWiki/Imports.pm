#! c:\perl\bin\perl
# Copyright 2006-2009 by Craig Dawson
#
# Distributed with the understanding that the owner(s) cannot be
# responsible for any behavior of the program or any damages that it
# may cause. See wikionly/LegalNotice.
#

use strict;
package Imports;

sub doit
{
    my @allLines;
    my @flankLines = ('', '', '');

    push @allLines, "/'/':= update: use Imports;";
    push @allLines, "/'/':= update: return Imports::doit(\@_);";
    push @allLines, "/'/':= donotedit:";
    push @allLines, "----";

    my $line;
    use constant COLS => 2;

    if (opendir(D, "Imports"))
    {
        my @files = sort readdir(D);

        closedir(D);

        my $i = 0;
        foreach my $file (@files)
        {
            next if ($file eq ".");
            next if ($file eq "..");

            $i++;

            my $fileUrl = URLEncode($file);

            $line .= "|| [local://Imports/$fileUrl $file] ";

            if (($i % COLS) == 0)
            {
                $line .= "||";
                push @allLines, $line;
                $line = "";
            }
        }

        # Fill empty part of table
        while (($i % COLS) != 0)
        {
            $line .= "||";
            $i++;
        }
        #$line .= "||";
        push @allLines, $line;
    }

    chomp $flankLines[0];
    chomp $flankLines[2];
    return ($flankLines[0], @allLines, $flankLines[2]);
}

sub doDir {
    my ($dir, $nlink) = @_;
    my ($dev, $ino, $mode, $subcount);

# At the top level, we need to find nlink ourselves.

    ($dev,$ino,$mode,$nlink) = stat('.') unless $nlink;

# Get the list of files in the current directory.

    opendir(DIR,'.') || die "Can't open $dir";
    my (@filenames) = readdir(DIR);
    closedir(DIR);

    if ($nlink == 2) {        # This dir has no subdirectories.
        for (@filenames) {
            next if $_ eq '.';
            next if $_ eq '..';
            print "$dir/$_\n";
        }
    }
    else {                    # This dir has subdirectories.
        $subcount = $nlink - 2;
        for (@filenames) {
            next if $_ eq '.';
            next if $_ eq '..';
            my $name = "$dir/$_";
            print $name,"\n";
            next if $subcount == 0;    # Seen all the subdirs?

# Get link count and check for directoriness.

                ($dev,$ino,$mode,$nlink) = lstat($_);
            next unless -d _;

# It really is a directory, so do it recursively.

            chdir $_ || die "Can't cd to $name";
            &dodir($name,$nlink);
            chdir '..';
            --$subcount;
        }
    }
}

sub URLEncode {
    my $theURL = $_[0];
   $theURL =~ s/([\W])/"%" . uc(sprintf("%2.2x",ord($1)))/eg;
   return $theURL;
}

1;

