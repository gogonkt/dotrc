#! c:\perl\bin\perl
# Copyright 2006-2009 by Craig Dawson
#
# Distributed with the understanding that the owner(s) cannot be
# responsible for any behavior of the program or any damages that it
# may cause. See wikionly/LegalNotice.
#

use strict;
package chkspell;
use File::Copy;

#
# Check spelling in doxWiki using aspell
#
sub doit
{
    my @allLines;

    push @allLines, "/'/':= update: use chkspell;";
    push @allLines, "/'/':= update: return chkspell::doit(\@_);";
    push @allLines, "/'/':= donotedit:";
    push @allLines, "/'/' Start Area Here";
    push @allLines, "!! Check Spelling";
    push @allLines, "* WikiPageNOwiki [Edit\@40] (make sure to use a wiki word)";
    push @allLines, "----";
    push @allLines, "=bartable H3";
    my $rawpg = $main::EditBoxArray[1];
    my $pg = "pages/$rawpg";
    push @allLines, "||[\@4]Possibly Misspelled Words on $rawpg||";
    open (SPELL, "aspell -p ./doxwiki.en.pws list < $pg |");
    my $num = 0;
    while (<SPELL>)
    {
        my $line;

        chomp;
        $line = "|| $_ ||";
        $num++;

        my $n;
        if ($n = <SPELL>)
        {
            chomp $n;
            $line .= " $n ";
            $num++;
        }
        $line .= "||";

        if ($n = <SPELL>)
        {
            chomp $n;
            $line .= " $n ";
            $num++;
        }
        $line .= "||";

        if ($n = <SPELL>)
        {
            chomp $n;
            $line .= " $n ";
            $num++;
        }
        $line .= "||";

        push @allLines, $line;
    }
    push @allLines, "$num words found.";

    return (@allLines);
}


1;
