#! c:\perl\bin\perl
# Copyright 2004-2009 by Keith McClelland
#
# Distributed with the understanding that the owner(s) cannot be
# responsible for any behavior of the program or any damages that it
# may cause. See wikionly/LegalNotice.
#

use strict;
use English;

my ($port, $edSize) = @ARGV;
$port = 80 unless $port;
$| = 1;
print scalar(localtime $^T) . "; running on port $port\n";

my $WNOHANG = 1;  # require "sys/wait.h"
my $AF_INET = 2;
my $SOCK_STREAM = 1;
my $sockaddr = 'S n a4 x8';

my ($name, $aliases , $proto ) = getprotobyname ('tcp');
my $this = pack($sockaddr, $AF_INET, $port, "\0\0\0\0");
select(NS); $| = 1;
socket(S, $AF_INET, $SOCK_STREAM, $proto) || die "socket: $!";
bind(S,$this) || die "bind: $!";
listen(S,5) || die "connect: $!";
select(S); $| = 1; select(NS);

for($main::con = 1; ; $main::con++)
{
    $main::addr = accept(NS,S) or die "accept: $!";
    &service();
}

sub service
{
    my ($af,$port,$inetaddr) = unpack($sockaddr, $main::addr);
    my @inetaddr = unpack('C4',$inetaddr);
    $inetaddr = join('.', @inetaddr);

    my $request = <NS>;
    ($main::method, $main::file, undef) = $request =~ /^(\S*) \/(\S*) (\S*)/;
    %main::head = ();
    while(<NS>)
    {
        s/\r|\n//g;
        last unless /\S/;
        $main::head{"\L$1"}=$2 if /^(\S*): (.*)/;
    }

    $main::file =~ s/\%(..)/pack('C', hex($1))/geo;
    print STDOUT "$main::con: $inetaddr $main::method $main::file\n";
    ($main::file, $main::query) = ($PREMATCH, $POSTMATCH)
        if $main::file =~ /\?/;
    $main::file = "wiki.cgi" unless $main::file;
    $main::file =~ /\.cgi$/
        ? &invoke($inetaddr)
        : &doxCopy();
    close(NS);
}

sub index
{
    $main::file =~ s/\/$//;
    opendir(D, $main::file);
    print NS
        "<h1>$main::file/</h1><ul>\n",
        map("<li><a href=$main::file/$_>$_</a>\n", readdir(D)),
        "</ul>\n";
    closedir(D);
}


sub invoke
{
    my $path = $ENV{'PATH'};
    my $tz = undef;
    $tz = $ENV{'TZ'} if defined $ENV{'TZ'};
    local (%ENV);
    $ENV{'PATH'} = $path;
    $ENV{'TZ'} =  $tz if defined $tz;
    $ENV{REQUEST_METHOD} = $main::method;
    $ENV{QUERY_STRING} = $main::query if $main::query;
    $ENV{CONTENT_LENGTH} = $main::head{'content-length'} if $main::head{'content-length'};
    $ENV{HTTP_REFERER} = $main::head{'referer'} if $main::head{'referer'} ;
    $ENV{SERVER_SOFTWARE} = 'SimpleHTTP.pl';  # used later in save.cgi
    $ENV{ED_WINDOW_SIZE} = $edSize if $edSize;
    $ENV{REMOTE_ADDR} = $_[0];
    print "HTTP/1.0 200\r\n";
    do $main::file;
    $/ = "\n";  # failsafe restore of EOL
    print NS join('<br />', split("\n",$@)) if $@;
    # see p139 for more ideas
}

sub doxCopy
{
    open(F, $main::file);
    binmode F;
    my $buf;
  copy:
    while (my $len = sysread(F, $buf, 10240))
    {
        if (!defined $len)
        {
            next if $! =~ /^Interrupted/;
            last copy;
        }
        my $offset = 0;
        while ($len)
        {   # Handle partial writes.
            my $written = syswrite(NS, $buf, $len, $offset);
            last copy unless defined $written;
            $len -= $written;
            $offset += $written;
        }
    }
    close(F);
}
